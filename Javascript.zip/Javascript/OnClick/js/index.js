function functionClick() {
		document.getElementById("demo").innerHTML = "Le paragraphe à changé lors du clique grâce au Javascript"
	}

	document.getElementById("coc").innerHTML = "Test"