var x = 4,
h = 10,
y = 1;
w = x + h - y;

// w = 4 + 10 - 1

console.log(w); 


////////////////////////////////////////////////

var e = "Salut," + " comment " + "vas-tu " + "?"

console.log(e);

////////////////////////////////////////////////

var a = 7;
var b = "Chaîne de caractère"

console.log(a);
console.log(b);