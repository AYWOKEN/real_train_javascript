var texte = "Bonjour, je m'appelle Awoken et je suis un développeur (presque)";
var texte1 = texte.length;

console.log(texte1);


//////////////////////////////////////


var phrase = "Ce texte est écris en Javascript";

document.getElementById('deko').innerHTML = "Cette ligne de texte est écrite grâce au Javascript"
