var a, b, c;
a = 5;
b = 10;
c = a * b;

document.getElementById("demo0").innerHTML = c;

function myFunctionClick() {
	document.getElementById("demo1").innerHTML = "Salut !"
	document.getElementById("demo2").innerHTML = "Aurevoir !"
}