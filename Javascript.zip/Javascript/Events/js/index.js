function functionClick(){
	document.getElementById('demo').innerHTML = Date()
	document.getElementById('class').innerHTML = "Re-cliquez pour actualiser l'heure"
};