var a = 1 + 1; // ADDITION			"+"


var b = 2 - 1; // SOUSTRACTION		"-"


var c = 15 / 3; // DIVISION			"/"


var d = 5 * 5; // MULTIPLICATION	"*"


var e = 9 % 2; // MODULO			"%"


var f = 2 > 1; // PLUS GRAND QUE	">"


var g = 1 < 2; // PLUS PETIT QUE	"<"