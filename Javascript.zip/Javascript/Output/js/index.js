document.getElementById("demo").innerHTML = "Ceci est un paragraphe écris grâce au javascript";


function myFunction() {
	document.getElementById("test").innerHTML = "Tu as vu ?"
}

console.log(45 + 52);