var voiture = ["Mercedes ", " Ferrari", " Renault"]

document.getElementById('merco').innerHTML = voiture[0];
document.getElementById('ferr').innerHTML = voiture[1];
document.getElementById('ren').innerHTML = voiture[2];

var a = voiture[0].length;
console.log(a);