var a, b, c; // On affiche dans un ordre respectif les variables sinon la console affiche "NaN".

// Puis on donne ensuite une valeur aux variables toujours en suivant l'ordre.
a = 20; 
b = 15;
c = a - b;



/////////////////////////////////////////////////////////////////



var prenom = "Salut" // On peut aussi écrire 'salut'

console.log(a + ",", b + ",", c + ",") 
console.log(c) // Résultat de a - b (20 - 15)

/////////////////////////////////////////////////////////////////


console.log(50 + 12) * 3; //On multiplie de résultat de 50 + 12 par trois
console.log(a * 3); // On multiplie la valeur de la variable "a" (20) par trois