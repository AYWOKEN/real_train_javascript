var carName = "Fiat";

console.log(window.carName);


//////////////////////


function maFonction() {
	console.log("Renault");
};

maFonction()