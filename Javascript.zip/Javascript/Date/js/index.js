var a = new Date("August 11, 2017 02:50:45");

document.getElementById('demo').innerHTML = a;


var b = new Date();

document.getElementById("dena").innerHTML = b.toDateString();


var c = new Date();

document.getElementById('deno').innerHTML = c.getFullYear() + " Year"


var d = new Date();

document.getElementById('deni').innerHTML = d.getDay() + " (Day)"
